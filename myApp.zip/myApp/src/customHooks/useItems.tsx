// import React, { useCallback, useEffect, useState } from 'react';
// import { ItemProps } from '../interfaces/ItemProps';
// import { createItem, getItems, updateItem } from '../providers/itemsApi';
// import { getLogger } from '../utils/utils';

// const log = getLogger('useItems');


// export interface ItemsState {
//   items?: ItemProps[],
//   fetching: boolean,
//   fetchingError?: Error,
//   saving: boolean,
//   savingError?:Error
// }

// export interface ItemsHook extends ItemsState {
//   saveItem: SaveItemFn;
// }

// type SaveItemFn = (item: ItemProps) => Promise<any>;

// export const useItems: () => ItemsHook = () => {
//   const [fetching, setFetching] = useState<boolean>(false);
//   const [items, setItems] = useState<ItemProps[]>();
//   const [fetchingError, setFetchingError] = useState<Error>();
//   const [saving, setSaving]= useState<boolean>(false);
//   const [savingError, setSavingError] = useState<Error>();

//   const saveItem = useCallback<SaveItemFn>(saveItemCallback, []);

//   useEffect(getItemsEffect, []);

//   log(`returns - fetching = ${fetching}, items = ${JSON.stringify(items)}`);

//   return {
//     items,
//     fetching,
//     fetchingError,
//     saving,
//     savingError,
//     saveItem,
//   };

//   function getItemsEffect() {
//     let canceled = false;
//     fetchItems();
//     return () => {
//       canceled = true;
//     }

//     async function fetchItems() {
//       try {
//         log('fetchItems started');

//         setFetching(true);
//         const items = await getItems();

//         log('fetchItems succeeded');

//         if (!canceled) {
//           setFetching(false);
//           setItems(items);
//         }

//       } catch (error: any) {
        
//         log('fetchItems failed');
//         if (!canceled) {
//           setFetching(false);
//           setFetchingError(error);
//         }
//       }
//     }
//   }

//   async function saveItemCallback(item: ItemProps) {
//     try {
//       log('saveItem started');
//       setSaving(true);
//       const savedItem = await (item.id ? updateItem(item) : createItem(item));
//       log('saveItem succeeded');
//       setSaving(false);
//     } catch (error: any) {
//       log('saveItem failed');
//       setSavingError(error);
//     }
//   }
// };

export function useItems(){}