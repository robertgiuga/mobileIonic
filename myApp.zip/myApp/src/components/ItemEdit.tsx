import React, {
  useCallback,
  useContext,
  useEffect,
  useReducer,
  useRef,
  useState,
} from "react";
import {
  IonActionSheet,
  IonButton,
  IonButtons,
  IonContent,
  IonDatetime,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonLoading,
  IonModal,
  IonPage,
  IonRadio,
  IonRadioGroup,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { RouteComponentProps } from "react-router";
import { ItemProps } from "../interfaces/ItemProps";
import { getLogger } from "../utils/utils";
import { ItemContext } from "./ItemProvider";
import { MyPhoto, usePhotos } from "../camera/usePhotos";
import { camera, close, trash } from "ionicons/icons";
import { CreateAnimation, createAnimation } from "@ionic/react";
import { useMyLocation } from "../maps/useMyLocation";
import MyMap from "../maps/MyMap";

const log = getLogger("ItemEdit");

interface ItemEditProps
  extends RouteComponentProps<{
    id?: string;
  }> {}

interface Cords {
  lat?: number;
  lng?: number;
}

const cordState: Cords = {
};

const reducer: (state: Cords, newstate: Cords) => Cords = (
  state,
  { lat, lng }
) => {
  return { lat, lng };
};

const ItemEdit: React.FC<ItemEditProps> = ({ history, match }) => {
  const { items, saving, savingError, saveItem } = useContext(ItemContext);
  const [text, setText] = useState("");
  const [item, setItem] = useState<ItemProps>();
  const [date, setDate] = useState<string | any>(null);
  const [selected, setSelected] = useState<boolean | any>();
  const { photos, takePhoto, deletePhoto } = usePhotos(
    match.params.id ? match.params.id : ""
  );
  const [photoToDelete, setPhotoToDelete] = useState<MyPhoto>();

  useEffect(() => {
    log("useEffect");
    const routeId = match.params.id || "";
    const item = items?.find((it) => it._id === routeId);
    setItem(item);
    if (item) {
      setText(item.text);
      setDate(item.date);
      setSelected(item.selected);
      setCord({ lat: item.cords?.lat, lng: item.cords?.lng });
    }
  }, [match.params.id]);

  const [cords, setCord] = useReducer(reducer, cordState);

  const handleSave = useCallback(() => {
    //const photo =photos.length>0? photos[0].webviewPath: "";
    const editedItem = item
      ? { ...item, text, date, selected, cords }
      : { text, date, selected, cords };
    saveItem && saveItem(editedItem).then(() => history.goBack());
  }, [saveItem, text, date, selected, photos, cords]);

  const datetime = useRef<null | HTMLIonDatetimeElement>(null);
  useEffect(simpleAnimation, []);
  const myLocation = useMyLocation();
  const { latitude: lat, longitude: lng } = myLocation.position?.coords || {};

  //useEffect(()=>{setCord({ lat:lat, lng:lng});}, [myLocation]);
  //console.log(lat, lng);
  log("render");
  return (
    <IonPage className="page">
      <IonHeader>
        <IonToolbar>
          <IonTitle>Edit</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={handleSave}>Save</IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div style={{ display: "flex" }}>
          <div style={{ width: "80%" }}>
            <IonInput
              value={text}
              onIonChange={(e) => setText(e.detail.value || "")}
            />
            <IonDatetime
              value={date}
              ref={datetime}
              onIonChange={(e) => setDate(e.detail.value || "")}
            ></IonDatetime>
            <IonItem>
              <IonLabel>Selected</IonLabel>
              <IonRadioGroup
                value={selected ? "selected" : null}
                allowEmptySelection
                onIonChange={(e) => {
                  setSelected(e.detail.value === "selected");
                }}
              >
                <IonRadio value="selected" slot="end" />
              </IonRadioGroup>
            </IonItem>
          </div>
          <div style={{ float: "right" }}>
            {photos.length > 0 && (
              <IonImg
                style={{ height: "200px", width: "100%" }}
                onClick={() => setPhotoToDelete(photos[0])}
                src={photos[0].webviewPath}
              />
            )}
          </div>
        </div>
        <div style={{ display: "block" }}>
          <div>{cords.lat? "Item Location is" : "Items has no Location" }</div>
          {cords.lat && cords.lng && (
            <>
              <div>latitude: {cords.lat}</div>
              <div>longitude: {cords.lng}</div>
            </>
          )}
          {!cords.lat && !cords.lng && (
            <IonButton onClick={()=>setCord({ lat:lat, lng:lng})}>Selecteaza Locatie</IonButton>
          )}
        </div>
        {cords.lat && cords.lng && (
          <MyMap
            lat={cords.lat}
            lng={cords.lng}
            onMapClick={log("onMap")}
            onMarkerClick={log("onMarker")}
          />
        )}
        <IonFab vertical="bottom" horizontal="center" slot="fixed">
          <IonFabButton
            disabled={photos.length > 0}
            onClick={() => takePhoto()}
          >
            <IonIcon icon={camera} />
          </IonFabButton>
        </IonFab>
        <IonActionSheet
          isOpen={!!photoToDelete}
          buttons={[
            {
              text: "Delete",
              role: "destructive",
              icon: trash,
              handler: () => {
                if (photoToDelete) {
                  deletePhoto(photoToDelete);
                  setPhotoToDelete(undefined);
                }
              },
            },
            {
              text: "Cancel",
              icon: close,
              role: "cancel",
            },
          ]}
          onDidDismiss={() => setPhotoToDelete(undefined)}
        />
        <IonLoading isOpen={saving} />
        {savingError && (
          <div>{savingError.message || "Failed to save item"}</div>
        )}
      </IonContent>
    </IonPage>
  );

  function log(source: string) {
    return (e: any) => {
      console.log(source, e.latitude, e.longitude);
      setCord({ lat: e.latitude, lng: e.longitude });
    };
  }
};
export default ItemEdit;

function simpleAnimation() {
  const page = document.querySelector(".page");
  if (page) {
    const animation = createAnimation()
      .addElement(page)
      .duration(1000)
      .fromTo("opacity", "0.01", "var(--backdrop-opacity)")
      .easing("ease-out");

    animation.play();
  }
}
