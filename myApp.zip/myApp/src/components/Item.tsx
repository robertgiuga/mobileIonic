import { IonButton, IonDatetime, IonItem, IonLabel, IonPicker, IonRadio, IonRadioGroup } from "@ionic/react";
import React, { memo, useCallback } from "react"
import { ItemProps } from "../interfaces/ItemProps";
import { getLogger } from "../utils/utils";

const log = getLogger('Item');

interface ItemPropsExt extends ItemProps {
    onEdit: (id?: string) => void;
  }
  
const  Item:React.FC<ItemPropsExt> =({_id, text,selected, onEdit})=>{
  const handleEdit = useCallback(() => onEdit(_id), [_id, onEdit]);
    log(`render ${text}`);
    return (<IonItem onClick={handleEdit}>
        <IonLabel>{text}</IonLabel>
        <IonRadioGroup value={selected? "selected": null}>
          <IonRadio value="selected" slot="end"/>
        </IonRadioGroup>
        </IonItem>
    )
};

export default memo(Item);