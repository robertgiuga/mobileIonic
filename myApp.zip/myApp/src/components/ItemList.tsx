import {
  IonButton,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItemGroup,
  IonLabel,
  IonList,
  IonLoading,
  IonPage,
  IonRadio,
  IonRadioGroup,
  IonSearchbar,
} from "@ionic/react";
import React, { useContext, useEffect, useState } from "react";
import { getLogger } from "../utils/utils";
import Item from "./Item";
import { add } from "ionicons/icons";
import { RouteComponentProps } from "react-router";
import { ItemContext } from "./ItemProvider";
import { useNetwork } from "../network/useNetwork";
import { AuthContext } from "../auth";

const log = getLogger("ItemList");

const ItemList: React.FC<RouteComponentProps> = ({ history }) => {
  const {logout}= useContext(AuthContext);
  const { items, fetching, fetchingError } = useContext(ItemContext);
  const { networkStatus } = useNetwork();
  const [searchItem, setSearchItem] = useState<string>('');
  const [selected, setSelected] = useState<string>('none');
  const [disableInfiniteScroll, setDisableInfiniteScroll] = useState<boolean>(false);
  const [n, setN]= useState(9);
  var itemsCopy=items?.map(x=>x).splice(0,n);
  useEffect(()=>{itemsCopy=items?.map(x=>x).splice(0,n)},[n]);

  console.log(itemsCopy);
  async function searchNext($event: CustomEvent<void>) {
    setN(n+9);
    if(items && n >= items?.length)
      setDisableInfiniteScroll(true);
    ($event.target as HTMLIonInfiniteScrollElement).complete();
  }
  log("render");
  return (
    <IonPage>
      <IonHeader>
      <IonItemGroup style={{paddingLeft: '20px'}}>
            <IonLabel>You are: {networkStatus.connected? "online":"offline"}</IonLabel>
            <IonSearchbar
              value={searchItem}
              debounce={100}
              onIonChange={e =>setSearchItem(e.detail.value!)}>
            </IonSearchbar>
            <IonLabel>Filter by:</IonLabel>
          <IonRadioGroup value={selected} onIonChange={e=> {setSelected(e.detail.value)}}>
                <IonLabel>selected</IonLabel>
                <IonRadio value="selected"></IonRadio>
                <IonLabel>unselected</IonLabel>
                <IonRadio value="unselected"></IonRadio>
                <IonLabel>none</IonLabel>
                <IonRadio value="none"></IonRadio>
            </IonRadioGroup>
        </IonItemGroup>
        <IonButton onClick={()=>{logout?.(); history.push('/login')}}>
          LogOut
        </IonButton>
      </IonHeader>
      <IonContent>
      <IonLoading isOpen={fetching} message="Fetching items" />
        {itemsCopy&& (
          <IonList>
          
          {itemsCopy.filter(it=>searchItem==''? true: it.text==searchItem).filter(it=> selected=='none'? true: it.selected== (selected=='selected')).map(({ _id, text,selected}) => <Item key={_id} _id ={_id} selected={selected} text={text} onEdit={_id => history.push(`/item/${_id}`)} />)}
          </IonList>
        )}
        {fetchingError && (
          <div>{fetchingError.message || 'Failed to fetch items'}</div>
        )}
        <IonInfiniteScroll threshold="100px"  disabled={disableInfiniteScroll}
                           onIonInfinite={(e: CustomEvent<void>) => searchNext(e)}>
          <IonInfiniteScrollContent
            loadingText="Loading more items">
          </IonInfiniteScrollContent>
        </IonInfiniteScroll>

        <IonFab vertical="bottom" horizontal="end" slot="fixed">
          <IonFabButton onClick={() => history.push('/item')}>
            <IonIcon icon={add} />
          </IonFabButton>
        </IonFab>
      </IonContent>
    </IonPage>
  );
};

export default ItemList;
