import React, { useCallback, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { getLogger } from '../core';
import { login as loginApi } from './authApi';
import { Preferences  } from '@capacitor/preferences';

const log = getLogger('AuthProvider');

type LoginFn = (username?: string, password?: string) => void;
type LogoutFn = () => void;

export interface AuthState {
  authenticationError: Error | null;
  isAuthenticated: boolean;
  isAuthenticating: boolean;
  login?: LoginFn;
  logout?: LogoutFn;
  pendingAuthentication?: boolean;
  username?: string;
  password?: string;
  token: string;
}

const initialState: AuthState = {
  isAuthenticated: false,
  isAuthenticating: false,
  authenticationError: null,
  pendingAuthentication: false,
  token: '',
};

export const AuthContext = React.createContext<AuthState>(initialState);

interface AuthProviderProps {
  children: PropTypes.ReactNodeLike,
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, setState] = useState<AuthState>(initialState);
  const { isAuthenticated, isAuthenticating, authenticationError, pendingAuthentication, token } = state;
  getTokenIfExist();
  const login = useCallback<LoginFn>(loginCallback, []);
  const logout= useCallback<LogoutFn>(removeToken, []);
  useEffect(authenticationEffect, [pendingAuthentication]);
  const value = { isAuthenticated, login, logout, isAuthenticating, authenticationError, token };
  log('render');
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );

  function loginCallback(username?: string, password?: string): void {
    log('login');
    setState({
      ...state,
      pendingAuthentication: true,
      username,
      password
    });
  }

  function authenticationEffect() {
    let canceled = false;
    authenticate();
    return () => {
      canceled = true;
    }

    async function authenticate() {
      if(isAuthenticated){
        log("allready authenticated");
        return;
      }
      if (!pendingAuthentication) {
        log('authenticate, !pendingAuthentication, return');
        return;
      }
      try {
        log('authenticate...');
        setState({
          ...state,
          isAuthenticating: true,
        });
        const { username, password } = state;
        const { token } = await loginApi(username, password);
        log(token);
        if (canceled) {
          return;
        }
        state.token=token;
        state.isAuthenticated=true;
        state.pendingAuthentication=false;
        state.isAuthenticating=false;
        log('authenticate succeeded');
        setToken(token);
        setState({
          ...state,
          token: token,
          pendingAuthentication: false,
          isAuthenticated: true,
          isAuthenticating: false,
        });
        return;
      } catch (error) {
        if (canceled) {
          return;
        }
        log('authenticate failed');
        setState({
          ...state,
          authenticationError: error,
          pendingAuthentication: false,
          isAuthenticating: false,
        });
      }
    }
  }

  async function getTokenIfExist(){
    if(isAuthenticated){
      return;
    }
    const res = await Preferences.get({ key: 'token' });
    console.log(res);
    const token =JSON.parse(res.value? res.value: "");
    console.log(token);
    if (res.value) {
        log('user allready authenticated');
        setState({
          ...state,
          pendingAuthentication: false,
          isAuthenticated: true,
          isAuthenticating: false,
          ...token
        });
    } else {
       log('user not auth');
    }
  }

  async function setToken(token:string) {
    log("save token");
    await Preferences.set({
      key: 'token',
      value: JSON.stringify({
        token
      })
    });
  }

  async function removeToken() {
    await Preferences.remove({ key: 'token' });
    setState({
      ...state,
      token: '',
      pendingAuthentication: false,
      isAuthenticating: false,
      isAuthenticated: false
    });
    log("token removed")
  }
};
