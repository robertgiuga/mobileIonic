import React, { useContext, useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
import { RouteComponentProps } from "react-router";
import {
  IonButton,
  IonContent,
  IonHeader,
  IonInput,
  IonLoading,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { AuthContext } from "./AuthProvider";
import { getLogger } from "../core";
import { CreateAnimation, createAnimation } from "@ionic/react";

const log = getLogger("Login");

interface LoginState {
  username?: string;
  password?: string;
}

export const Login: React.FC<RouteComponentProps> = ({ history }) => {
  const { isAuthenticated, isAuthenticating, login, authenticationError } =
    useContext(AuthContext);
  const [state, setState] = useState<LoginState>({});
  const { username, password } = state;

  useEffect(simpleAnimation,[])

  
  const handleLogin = () => {
    log("handleLogin...");
    login?.(username, password);
  };
  log("render");
  if (isAuthenticated) {
    return <Redirect to={{ pathname: "/" }} />;
  }
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Login</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonInput
          placeholder="Username"
          value={username}
          onIonChange={(e) =>
            setState({ ...state, username: e.detail.value || "" })
          }
        />
        <IonInput
          placeholder="Password"
          value={password}
          onIonChange={(e) =>
            setState({ ...state, password: e.detail.value || "" })
          }
        />
      </IonContent>
      <IonLoading isOpen={isAuthenticating} />
      {authenticationError && (
        <div>{authenticationError.message || "Failed to authenticate"}</div>
      )}
      <IonButton class="login" onClick={handleLogin}>
        Login
      </IonButton>
    </IonPage>
  );
};

function simpleAnimation() {
  const btn = document.querySelector(".login");
  if (btn) {
    const animation = createAnimation()
      .addElement(btn)
      .duration(1000)
      .direction("alternate")
      .iterations(Infinity)
      .keyframes([
        { offset: 0, transform: "scale(1)", opacity: "1" },
        { offset: 1, transform: "scale(1.5)", opacity: "0.5" },
      ]);
      animation.play();
  }
}
