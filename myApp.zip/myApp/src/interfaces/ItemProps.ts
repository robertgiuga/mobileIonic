export interface ItemProps {
    _id?: string;
    text: string;
    date?: string;
    selected?: boolean;
    photo?: string;
    cords?: {lat?:number, lng?:number};
  }
  