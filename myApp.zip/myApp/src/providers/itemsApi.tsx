import axios from 'axios';
import { authConfig } from '../core';
import { ItemProps } from '../interfaces/ItemProps';
import { getLogger } from '../utils/utils';

const log = getLogger('itemApi');

const baseUrl = 'localhost:3000';
const itemUrl = `http://${baseUrl}/api/item`;

interface HttpResponse<T>{
    data: T;
}

function withLogs<T>(promise: Promise<HttpResponse<T>>, action: string): Promise<T> {
  log(`${action} - started`);
  
  return promise
    .then(res => {
      log(`${action} - succeeded`);
      return Promise.resolve(res.data);
    })
    .catch(err => {
      log(`${action} - failed`);
      return Promise.reject(err);
    });
}



export const getItems: (token: string) => Promise<ItemProps[]> = token => {
  return withLogs(axios.get(itemUrl, authConfig(token)), 'getItems');
}

export const createItem: (token: string, item: ItemProps) => Promise<ItemProps[]> = (token, item) => {
  return withLogs(axios.post(itemUrl, item, authConfig(token)), 'createItem');
}

export const updateItem: (token: string, item: ItemProps) => Promise<ItemProps[]> = (token, item) => {
  return withLogs(axios.put(`${itemUrl}/${item._id}`, item, authConfig(token)), 'updateItem');
}


interface MessageData {
  event: string;
  payload: {
    item: ItemProps;
  };
}

export const newWebSocket = (token: string, onMessage: (data: MessageData) => void) => {
  const ws = new WebSocket(`ws://${baseUrl}`);
  ws.onopen = () => {
    log('web socket onopen');
    ws.send(JSON.stringify({ type: 'authorization', payload: { token } }));
  };
  ws.onclose = () => {
    log('web socket onclose');
  };
  ws.onerror = error => {
    log('web socket onerror', error);
  };
  ws.onmessage = messageEvent => {
    log('web socket onmessage');
    onMessage(JSON.parse(messageEvent.data));
  };
  return () => {
    ws.close();
  }
}
