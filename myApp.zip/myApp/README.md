Item -> has the following props:
    - id -> string;
    - text -> string;
    - date -> string;
    - selected -> boolean;